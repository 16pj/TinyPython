This folder is used to temporarily store image files.
