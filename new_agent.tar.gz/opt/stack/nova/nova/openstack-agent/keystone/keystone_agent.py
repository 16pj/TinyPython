from nova.nova_agent import *
from request import *
from common import *

#FOR FED SCOPED TOKEN

import os, json, requests, re
from subprocess import Popen, PIPE

#config = ConfigParser.ConfigParser()
#config.read('agent.conf')
#KEYSTONE_ENDPOINT_PUBLIC = config.get('Keystone','site') + ':' + config.get('Keystone','keystone_public_interface')
#KEYSTONE_ENDPOINT_ADMIN =  config.get('Keystone','site') + ':' + config.get('Keystone','keystone_admin_interface')
#KEYSTONE_ENDPOINT_INTERNAL = config.get('Keystone','site') + ':' + config.get('Keystone','keystone_internal_interface')
#AGENT_IP = config.get('Agent','site_ip')
#AGENT_PORT = config.get('Agent','listen_port')


###############################################
###########   Identity API v2   ###############
###############################################

# Authenticate users via username and password
def authentication(username,password):
    data = {
	"auth": {"passwordCredentials":{"username": username, "password": password}}
    }

    req = urllib2.Request(KEYSTONE_ENDPOINT_PUBLIC+'/v2.0/tokens')
    req.add_header('Content-Type','application/json')
    response = urllib2.urlopen(req,json.dumps(data))




def keystone_refresh_token(cloud_address, old_token):
    # request data
    PostData =  "{'auth': {'identity': {'methods': ['token'], 'token': {'id': '%s'}}, 'scope': 'unscoped'}" % old_token
    # Retrive token from request
    X_AUTH_TOKEN = env['HTTP_X_AUTH_TOKEN']
    # Create header
    headers = {'Accept': 'application/json', 'User-Agent': 'python-keystoneclient'}

    # Construct Keystone's url
    url = cloud_address + config.get('Keystone','keystone_public_interface') + '/v3/users'

    res = POST_request_to_cloud(url, headers, PostData)
    put_token_into_db(cloud_address, res.headers['X-Subject-Token'])
    return res.headers['X-Subject-Token']



# GETTING SCOPED TOKEN FROM IDP
def keystone_fed_authentication_v3(sp_id):

    auth_url = KEYSTONE_IDP_ENDPOINT_PUBLIC + '/v3/auth/tokens'
    project_domain = KEYSTONE_IDP_PROJECT_DOMAIN
    user_domain = KEYSTONE_IDP_USER_DOMAIN
    project_name = KEYSTONE_IDP_PROJECT_NAME
    user_name = KEYSTONE_IDP_USERNAME
    password = KEYSTONE_IDP_PASSWORD

    # IDP TOKEN RETRIEVAL

    headers = {'Content-Type': 'application/json'}
    data = {"auth": {"scope": {"project": {"domain": {"name": project_domain}, "name": project_name}},
                     "identity": {"methods": ["password"], "password": {
                         "user": {"name": user_name, "password": password, "domain": {"name": user_domain}}}}}}
    res = requests.post(auth_url, json=data, headers=headers)
    # print (res.status_code)
    # print (res.raise_for_status())
    # Get token from IDP
    IDP_token = res.headers['X-Subject-Token']
    if not IDP_token:
        print ("Couldn't obtain token from IDP")
    #print (IDP_token)

    # ASSERTION PART

    t = json.loads(res.text)
    sp = [x for x in t['token']['service_providers'] if x['id'] == sp_id]
    if len(sp) > 0:
        SP_URL = sp[0]['sp_url']
        SP_AUTH_URL = sp[0]['auth_url']
        print('SP_URL=' + SP_URL + '\nSP_AUTH_URL=' + SP_AUTH_URL)

    ecp_url = KEYSTONE_IDP_ENDPOINT_PUBLIC + '/v3/auth/OS-FEDERATION/saml2/ecp'
    data = {"auth": {"scope": {"service_provider": {"id": sp_id}},
                     "identity": {"token": {"id": IDP_token}, "methods": ["token"]}}}
    headers = {'X-Auth-Token': IDP_token, 'Content-Type': 'application/json'}
    res = requests.post(ecp_url, json=data, headers=headers)
    assertion = res.text

    o = open(assertion_file, 'w')
    o.write(assertion)
    o.close()

    # print "\n\n\n" + assertion + "\n\n\n\n"

    # data = assertion
    # headers1 = {'Content-Type': 'application/vnd.paos+xml'}
    # res1 = requests.post(SP_URL, json=data, headers=headers1)
    # res1.text

    # sub = Popen("curl -s -X POST -H 'X-Auth-Token': %s -H 'Content-Type: application/json' -d {'auth': {'scope': {'service_provider': {'id': %s}}, 'identity': {'token': {'id':%s}, 'methods': ['token']}}} %s/auth/OS-FEDERATION/saml2/ecp >assertion.xml 2>error.log" % (IDP_token, os.environ['SP_ID'], IDP_token, os.environ['OS_AUTH_URL']), shell=True)

    # output, error = sub.communicate()
    # print output

    sub = Popen("curl -s -X POST -H 'Content-Type: application/vnd.paos+xml' -c '%s' -d '@%s' %s >error.log 2>&1" % (
    cookie_file, assertion_file, SP_URL), shell=True)
    # output, error = sub.communicate()
    # print output

    dub = Popen(
        "curl -v -s -X GET -H 'Content-Type: application/vnd.paos+xml' -b '%s' %s >/dev/null 2>%s; cat %s | grep 'X-Subject-Token' | awk '{print $3}'" % (
        cookie_file, SP_AUTH_URL, unscoped_file, unscoped_file), shell=True, stdout=PIPE)
    SP_unscoped_token, error = dub.communicate()
    SP_unscoped_token = SP_unscoped_token.strip()
    #print (SP_unscoped_token)

    os.remove(cookie_file)
    os.remove(unscoped_file)

    SP_AUTH_URL_SHORT = re.compile(r'.*/v3').search(SP_AUTH_URL).group()
    SP_DOMAIN_URL = SP_AUTH_URL_SHORT + '/OS-FEDERATION/domains'
    headers = {'X-Auth-Token': SP_unscoped_token}
    res = requests.get(SP_DOMAIN_URL, headers=headers)
    fed_domain_name = json.loads(res.text)['domains'][0]['name']

    SP_PROJECT_URL = SP_AUTH_URL_SHORT + '/OS-FEDERATION/projects'
    res = requests.get(SP_PROJECT_URL, headers=headers)
    fed_project_name = json.loads(res.text)['projects'][0]['name']

    headers = {'X-Auth-Token': SP_unscoped_token, 'Content-Type': 'application/json'}
    scoped_url = SP_AUTH_URL_SHORT + '/auth/tokens'
    data = {"auth": {"identity": {"methods": ["mapped"], "mapped": {"id": SP_unscoped_token}},
                     "scope": {"project": {"domain": {"name": fed_domain_name}, "name": fed_project_name}}}}
    res = requests.post(scoped_url, json=data, headers=headers)
    SP_scoped_token = res.headers['X-Subject-Token']
    cloud_address = SP_AUTH_URL_SHORT

    return SP_scoped_token

# Verify user's token
def authenticate_token_v2(PostData):

    url = KEYSTONE_ENDPOINT_PUBLIC + '/v2.0/tokens'
    req = requests.post(url, data = PostData)
    show_response(inspect.stack()[0][3],res)


# Keystone API version discovery
def keystone_api_version_discovery(env):

    headers = {'Accept': 'application/json', 'User-Agent': 'python-keystoneclient'}

    url = KEYSTONE_ENDPOINT_PUBLIC + '/'

    res = GET_request_to_cloud(url, headers)

    response_body = res.json()

    for value in response_body['versions']['values']:
        if value['id'].startswith('v3'):
	    value['links'][0]['href'] = AGENT_IP + ':' + AGENT_PORT + '/v3/'
        else:
	    value['links'][0]['href'] = AGENT_IP + ':' + AGENT_PORT + '/v2.0/'

    return generate_formatted_response(res, response_body)

###############################################
###########   Identity API v3   ###############
###############################################












def keystone_domains_default(env):

    # Retrive token from request
    X_AUTH_TOKEN = env['HTTP_X_AUTH_TOKEN']

    # Create request header
    headers = {'Accept': 'application/json', 'User-Agent': 'python-keystoneclient', 'X-Auth-Token': X_AUTH_TOKEN}

    url = KEYSTONE_ENDPOINT_PUBLIC + '/v3/domains/default'

    res = GET_request_to_cloud(url, headers)

    response_body = res.json()
    #response_body['domain']['links']['self'] = AGENT_IP + ':' + AGENT_PORT + '/v3/domains/default'

    return generate_formatted_response(res, response_body)

# List roles
def keystone_list_roles(env):

    # Retrive token from request
    X_AUTH_TOKEN = env['HTTP_X_AUTH_TOKEN']

    # Create request header
    headers = {'Accept': 'application/json', 'User-Agent': 'python-keystoneclient', 'X-Auth-Token': X_AUTH_TOKEN}

    url = KEYSTONE_ENDPOINT_PUBLIC + '/v3/roles'

    res = GET_request_to_cloud(url, headers)

    response_body = res.json()
    #response_body['domain']['links']['self'] = AGENT_IP + ':' + AGENT_PORT + '/v3/domains/default'

    return generate_formatted_response(res, response_body)



def keystone_list_projects(env):

    # Retrive token from request
    X_AUTH_TOKEN = env['HTTP_X_AUTH_TOKEN']

    # Create request header
    headers = {'Accept': 'application/json', 'User-Agent': 'python-keystoneclient', 'X-Auth-Token': X_AUTH_TOKEN}

    url = KEYSTONE_ENDPOINT_PUBLIC + '/v3/projects'

    res = GET_request_to_cloud(url, headers)

    response_body = res.json()
    #response_body['domain']['links']['self'] = AGENT_IP + ':' + AGENT_PORT + '/v3/projects/default'

    return generate_formatted_response(res, response_body)


# Grant role to user on project
def keystone_grant_role_to_user_on_project(env):

    # Retrive token from request
    X_AUTH_TOKEN = env['HTTP_X_AUTH_TOKEN']

    # Create request header
    headers = {'Accept': 'application/json', 'User-Agent': 'python-keystoneclient', 'X-Auth-Token': X_AUTH_TOKEN}

    url = KEYSTONE_ENDPOINT_PUBLIC + env['PATH_INFO']

    res = requests.put(url, headers = headers)
    response_body = res.text

    return generate_formatted_response(res, response_body)

# Create a project
def keystone_create_project(env):
    # request data
    PostData = env['wsgi.input'].read()
    # Retrive token from request
    X_AUTH_TOKEN = env['HTTP_X_AUTH_TOKEN']
    # Create header
    headers = {'Accept': 'application/json', 'User-Agent': 'python-keystoneclient', 'X-Auth-Token': X_AUTH_TOKEN}

    # Construct Keystone's url
    url = KEYSTONE_ENDPOINT_PUBLIC + '/v3/projects'

    res = POST_request_to_cloud(url, headers, PostData)
    response_body = res.json()

    return generate_formatted_response(res, response_body)

# Create a user
def keystone_create_user(env):
    # request data
    PostData = env['wsgi.input'].read()
    # Retrive token from request
    X_AUTH_TOKEN = env['HTTP_X_AUTH_TOKEN']
    # Create header
    headers = {'Accept': 'application/json', 'User-Agent': 'python-keystoneclient', 'X-Auth-Token': X_AUTH_TOKEN}

    # Construct Keystone's url
    url = KEYSTONE_ENDPOINT_PUBLIC + '/v3/users'

    res = POST_request_to_cloud(url, headers, PostData)
    response_body = res.json()

    return generate_formatted_response(res, response_body)

# Delete project
def keystone_delete_project(env):

    site_pattern = re.compile(r'(?<=/projects/).*')
    match = site_pattern.search(env['PATH_INFO'])
    project_id = match.group()

    # request data
    PostData = env['wsgi.input'].read()
    # Retrive token from request
    X_AUTH_TOKEN = env['HTTP_X_AUTH_TOKEN']
    # Create header
    headers = {'Accept': 'application/json', 'User-Agent': 'python-keystoneclient', 'X-Auth-Token': X_AUTH_TOKEN}

    # Construct Keystone's url
    url = KEYSTONE_ENDPOINT_PUBLIC + env['PATH_INFO']

    res = DELETE_request_to_cloud(url, headers)
    response_body = res.text

    # Delte tenant's created resources
    if res.status_code == 204:
        delete_from_DB(AGENT_DB_ENGINE_CONNECTION, Image, Image.tenant_id, project_id)

    return generate_formatted_response(res, '')

# Delete user
def keystone_delete_user(env):
    # request data
    PostData = env['wsgi.input'].read()
    # Retrive token from request
    X_AUTH_TOKEN = env['HTTP_X_AUTH_TOKEN']
    # Create header
    headers = {'Accept': 'application/json', 'User-Agent': 'python-keystoneclient', 'X-Auth-Token': X_AUTH_TOKEN}

    # Construct Keystone's url
    url = KEYSTONE_ENDPOINT_PUBLIC + env['PATH_INFO']

    res = DELETE_request_to_cloud(url, headers)
    response_body = res.text

    return generate_formatted_response(res, '')

# A function to map Keystone API v3 endpoint to agent's identity service ednpoint
def keystone_mapping_api_v3_endpoint(env):

    headers = {'Accept': 'application/json', 'User-Agent': 'python-keystoneclient'}

    url = KEYSTONE_ENDPOINT_PUBLIC + '/v3'

    res = GET_request_to_cloud(url, headers)

    response_body = res.json()
    response_body['version']['links'][0]['href'] = AGENT_IP + ':' + AGENT_PORT + '/v3'

    return generate_formatted_response(res, response_body)


def keystone_authentication_v3(env):
    # request data
    PostData = env['wsgi.input'].read()

    # Construct Keystone's url
    url = KEYSTONE_ENDPOINT_PUBLIC + '/v3/auth/tokens'
    # Create header
    headers = {'Content-Type': 'application/json'}

    res = POST_request_to_cloud(url, headers, PostData)

    # If is scoped authrization
    try:
        is_scoped = res.json()['token']['catalog']
        # Map service endpoints to agent endpoints
        response_body = endpoints_mapping(res)
    except:
        response_body = res.json()

    return generate_formatted_response(res, response_body)



# A function to map OpenStack service endpoints to agent service endpoints
def endpoints_mapping(data):

    response = data.json()

    catalog = response['token']['catalog']

    for i in range(len(catalog)):

        catalog_name = catalog[i]['name']

        if catalog_name == 'neutron' or catalog_name == 'glance' or catalog_name == 's3' or catalog_name == 'ec2':
            for j in range(len(catalog[i]['endpoints'])):
                url = catalog[i]['endpoints'][j]['url']
                url_split = url.split('/')
                catalog[i]['endpoints'][j]['url'] = AGENT_IP + ':' + AGENT_PORT

        elif catalog_name == 'nova' or catalog_name == 'nova_legacy':
            for j in range(len(catalog[i]['endpoints'])):
                url = catalog[i]['endpoints'][j]['url']
                url_split = url.split('/')
                catalog[i]['endpoints'][j]['url'] = AGENT_IP + ':' + AGENT_PORT + '/' + url_split[3] + '/' + url_split[4]

        elif catalog_name == 'keystone':
            for j in range(len(catalog[i]['endpoints'])):
                url = catalog[i]['endpoints'][j]['url']
                url_split = url.split('/')
                catalog[i]['endpoints'][j]['url'] = AGENT_IP + ':' + AGENT_PORT + '/' + url_split[3]

    return response


