from common import *
from request import *
from db import *
from models import *
from hypervisorStatistics import hypervisorStatistics

# Select a cloud site to create object (image, network, VM etc)
def select_site_to_create_object(**kwargs):
    # Select a cloud at random
    #cloud_name =  random.choice(SITES.keys())
    #cloud_address = SITES[cloud_name]

    #cloud_name = 'Region1'
    #cloud_address = 'http://192.168.96.78'

    object_type = kwargs['object_type']
    tenant_id_agent = kwargs['tenant_id']

    neighbors = mc.get('neighbors')
    X_AUTH_TOKEN_AGENT = kwargs['X_AUTH_TOKEN']

    # Create at local cloud
    if len(neighbors) == 0:
        return AGENT_IP

    elif len(neighbors) == 1:
    	# Get tenant id

    	neighbor_ip = ':'.join(neighbors[0].ip_address.split(':')[:2])
    	urls = []

        X_AUTH_TOKEN = get_token_from_anyone(neighbor_ip)

        tenant_id = get_tenant_id(X_AUTH_TOKEN)

        if tenant_id_agent is None:
            tenant_id_agent = get_tenant_id(X_AUTH_TOKEN_AGENT)

        urls.append(neighbor_ip+':'+NOVA_PUBLIC_INTERFACE+'/v2.1/'+tenant_id+'/os-hypervisors/statistics')

    	urls.append(AGENT_IP+':'+NOVA_PUBLIC_INTERFACE+'/v2.1/'+tenant_id_agent+'/os-hypervisors/statistics')

    	hs_list = get_hypervisor_statistics(X_AUTH_TOKEN, urls)

        # Create an image
        if object_type == 'image':
            return image_weight(hs_list)

        # Create a VM
        elif object_type == 'vm':
            image_id = kwargs['image_id']
            return vm_weight(hs_list, image_id)

    # Power of two choices
    elif len(neighbors) >= 2:

    	#neighbor_ip = ':'.join(neighbors[0].ip_address.split(':')[:2])
    	urls = []
        tokens = []
        for neighbor in neighbors:
    	   neighbor_ip = ':'.join(neighbor.ip_address.split(':')[:2])

           X_AUTH_TOKEN = get_token_from_anyone(neighbor_ip)

           tenant_id = get_tenant_id(X_AUTH_TOKEN)

    	   urls.append(neighbor_ip+':'+NOVA_PUBLIC_INTERFACE+'/v2.1/'+tenant_id+'/os-hypervisors/statistics')
           tokens.append(X_AUTH_TOKEN)

        tenant_id = get_tenant_id(X_AUTH_TOKEN_AGENT)
        urls.append(AGENT_IP+':'+NOVA_PUBLIC_INTERFACE+'/v2.1/'+tenant_id+'/os-hypervisors/statistics')
        tokens.append(X_AUTH_TOKEN_AGENT)

        #hs_list = get_hypervisor_statistics(X_AUTH_TOKEN, urls)
        #hs_list = power_of_two_choices(hs_list)

        #hs_list = get_hypervisor_statistics(X_AUTH_TOKEN, power_of_two_choices(urls))
	urls, tokens = power_of_two_choices(urls, tokens)

        hs_list = get_hypervisor_statistics(urls, tokens)

        # Create an image
        if object_type == 'image':
            return image_weight(hs_list)

        # Create a VM
        elif object_type == 'vm':
            image_id = kwargs['image_id']
            return vm_weight(hs_list, image_id)


# Authenticate to Keystone and get tenant id
def get_tenant_id(X_AUTH_TOKEN):

    # Create request header
    headers = {'X-Auth-Token': X_AUTH_TOKEN, 'X-Subject-Token': X_AUTH_TOKEN}

    url = KEYSTONE_ENDPOINT_PUBLIC + '/v3/auth/tokens'
    res = GET_request_to_cloud(url, headers)
    tenant_id = res.json()['token']['project']['id']

    return tenant_id
    #buf = bytes(res.json()) + b'\0'
    #print len(buf)

def get_hypervisor_statistics(urls, X_AUTH_TOKEN):

    # Create request header
    headers = {'X-Auth-Token': X_AUTH_TOKEN}

    # Get generated threads
    threads = generate_threads_multicast(X_AUTH_TOKEN, headers, urls, GET_request_to_cloud)

    # Launch threads
    for i in range(len(threads)):
        threads[i].start()

    threads_res = []

    # Wait until threads terminate
    for i in range(len(threads)):
        res = threads[i].join()
        # If user has access to the resource
        if res.status_code == 200:
            threads_res.append(res)

    hs_list = []
    for res in threads_res:
    	hs = res.json()['hypervisor_statistics']
        cloud_ip = 'http://' + res.url.split('http://')[1].split(':')[0]
    	hypervisor_statistics = hypervisorStatistics(cloud_ip, hs['count'], hs['current_workload'], hs['disk_available_least'], hs['free_disk_gb'], hs['free_ram_mb'], hs['local_gb'], hs['local_gb_used'], hs['memory_mb'], hs['memory_mb_used'], hs['running_vms'], hs['vcpus'], hs['vcpus_used'])
	hs_list.append(hypervisor_statistics)

    return hs_list

# Select two at random
#def power_of_two_choices(hs_list):
#    ls = []
#    while len(ls) < 2:
#        random_selection = random.choice(hs_list)
#        if random_selection not in ls:
#            ls.append(random_selection)
#    return ls


# Select two at random
def power_of_two_choices(urls, tokens):
    ls = []
    while len(ls) < 2:
        random_selection = random.choice(urls)
        if random_selection not in ls:
            ls.append(random_selection)

    url_temp = []
    token_temp = []
    for i, token in enumerate(tokens):
        if urls[i] == ls[0]:
            url_temp.append(urls[i])
            token_temp.append(token)
        elif urls[i] == ls[1]:
            url_temp.append(urls[i])
            token_temp.append(token)
    return url_temp, token_temp

def image_weight(hs_list):
    fd_gb = 0
    cloud_address = AGENT_IP
    for hs in hs_list:
        if hs.free_disk_gb > fd_gb:
            fd_gb = hs.free_disk_gb
            cloud_address = hs.cloud_ip
    return cloud_address

def vm_weight(hs_list, image_id):
    max_weights = 0
    cloud_address = AGENT_IP

    # Check if image exists in clouds
    result = query_from_DB(AGENT_DB_ENGINE_CONNECTION, Image, columns = [Image.uuid_agent], keywords = [image_id])

    for hs in hs_list:
        #max_weights= 0
        for image in result:
            if image.cloud_address == hs.cloud_ip and hs.free_disk_gb>0 and hs.free_ram_mb>0 and (hs.memory_mb-hs.memory_mb_used) >0 and hs.disk_available_least>0:
                return hs.cloud_ip
            elif image.cloud_address != hs.cloud_ip:
                weights = hs.free_ram_mb+(hs.memory_mb-hs.memory_mb_used)
                if weights > max_weights:
                    max_weights = weights
                    cloud_address = hs.cloud_ip

    return cloud_address






