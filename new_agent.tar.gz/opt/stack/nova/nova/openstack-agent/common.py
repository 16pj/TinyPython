#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#

"""

Common functions

"""
import ConfigParser
import ast
import re
import json
import random
import memcache

config = ConfigParser.ConfigParser()
config.read('agent.conf')

DATABASE_NAME = config.get('Database', 'DATABASE_NAME')
DATABASE_USERNAME = config.get('Database', 'DATABASE_USERNAME')
DATABASE_PASSWORD = config.get('Database', 'DATABASE_PASSWORD')
AGENT_DB_ENGINE_CONNECTION = 'mysql+mysqldb://%s:%s@localhost/%s' % (DATABASE_USERNAME, DATABASE_PASSWORD, DATABASE_NAME)

TEMP_IMAGE_PATH = config.get('Glance', 'temp_image_path')
IMAGE_FILE_PATH = config.get('Glance', 'image_file_path')

MEMCACHED_SERVER_IP = config.get('CYCLON', 'memcached_server_ip')
mc = memcache.Client([MEMCACHED_SERVER_IP], debug=1)

AGENT_IP = config.get('Agent','site_ip')
AGENT_PORT = config.get('Agent','listen_port')

KEYSTONE_IDP_ENDPOINT_PUBLIC = config.get('Keystone','site') + ':' + config.get('Keystone','keystone_public_interface')
KEYSTONE_IDP_ENDPOINT_ADMIN =  config.get('Keystone','site') + ':' + config.get('Keystone','keystone_admin_interface')
KEYSTONE_IDP_ENDPOINT_INTERNAL = config.get('Keystone','site') + ':' + config.get('Keystone','keystone_internal_interface')

KEYSTONE_IDP_PROJECT_DOMAIN = config.get('Keystone','project_domain')
KEYSTONE_IDP_USER_DOMAIN = config.get('Keystone','user_domain')
KEYSTONE_IDP_PROJECT_NAME = config.get('Keystone','project_name')
KEYSTONE_IDP_USERNAME = config.get('Keystone','user_name')
KEYSTONE_IDP_PASSWORD = config.get('Keystone','password')


KEYSTONE_ENDPOINT_PUBLIC = AGENT_IP + ':' + config.get('Keystone','keystone_public_interface')
KEYSTONE_ENDPOINT_ADMIN =  AGENT_IP + ':' + config.get('Keystone','keystone_admin_interface')
KEYSTONE_ENDPOINT_INTERNAL = AGENT_IP + ':' + config.get('Keystone','keystone_internal_interface')


NOVA_PUBLIC_INTERFACE = config.get('Nova','nova_public_interface')
GLANCE_PUBLIC_INTERFACE = config.get('Glance','glance_public_interface')
NEUTRON_PUBLIC_INTERFACE = config.get('Neutron','neutron_public_interface')



def get_token_from_db(cloud_address):
    import db, models
    token_result = db.query_from_DB(AGENT_DB_ENGINE_CONNECTION, models.Tokens, columns = [models.Tokens.cloud_address], keywords = [cloud_address])
    token = token_result[0].token
    if token:
        return token


def put_token_into_db(cloud_address, token):
    import db, models
    token_result = db.query_from_DB(AGENT_DB_ENGINE_CONNECTION, models.Tokens,columns=[models.Tokens.cloud_address], keywords=[cloud_address])
    try:
     if token_result.count == 0:
        new_token = models.Tokens(cloud_address= cloud_address, token=token)
        db.add_to_DB(AGENT_DB_ENGINE_CONNECTION, new_token)

     else:
        db.update_in_DB(AGENT_DB_ENGINE_CONNECTION, models.Tokens, columns=[models.Tokens.cloud_address], keywords=[cloud_address], new_value_dic={'token': token})
     return "success"
    except:
     return "Failed to update db"



def get_sp_from_address(cloud_address):
    split_address = cloud_address.split('.')
    sp_id = 'mysp' + str(split_address[0][1]) +  str(split_address[3])
    return sp_id


def get_token_from_anyone(cloud_address, old_token = 'NONE'):
    if old_token == 'NONE':

        try:
            token = get_token_from_db(cloud_address)
        except:
                from keystone.keystone_agent import keystone_fed_authentication_v3
                token = keystone_fed_authentication_v3(get_sp_from_address(cloud_address))
                if token:
                    put_token_into_db(cloud_address, token)
        return token

    else:
        from keystone.keystone_agent import keystone_refresh_token
        token  = keystone_refresh_token(cloud_address, old_token)
        return token



# A function to send resonse to end-user if resource info dose exist in agent local DB
def non_exist_response(status_code, response_body):

    headers = {'Content-Type': 'application/json'}
    headers = ast.literal_eval(str(headers)).items()

    if type(response_body) == str:
        return status_code, headers, response_body
    elif type(response_body) == dict:
        return status_code, headers, json.dumps(response_body)

# A function to add cloud name and cloud ip to user response
def add_cloud_info_to_response(search_context, response):

    # Get cloud site information by using regualr expression
    site_pattern = re.compile(r'(?<=http://).*')
    match = site_pattern.search(search_context)
    # IP address of cloud
    site_ip = match.group()
    # Find name of cloud
    #site = SITES.keys()[SITES.values().index('http://'+site_ip)]

    # Add site information to json response
    #try:
    #    response['site'] = response['site'] + ', ' + site + '-' + site_ip
    #except:
    #    response['site'] = site + '-' + site_ip
    try:
    	response['site'] = response['site'] + site_ip
    except:
	response['site'] = site_ip

    return response

# Remove duplication information of response
def remove_duplicate_info(items, keyword):

    ids = []
    rs = []
    for item in items:
        if item not in rs and item[keyword] not in ids:
            ids.append(item[keyword])
            rs.append(item)
        else:
            for item2 in rs:
                if item[keyword] == item2[keyword]:
                    item2['site'] = item2['site'] + ', ' + item['site']
    return rs

# Modify response header in terms of Content-Length
def modify_response_header(headers, response_body):

    headers_dict = dict(headers)
    headers_dict['Content-Length'] = str(len(json.dumps(response_body)))
    headers = ast.literal_eval(str(headers_dict)).items()

    return headers

# A function to generate well-formatted response to end user
def generate_formatted_response(res, response_body):

    status_code = str(res.status_code)
    headers = res.headers
    headers['Content-Length'] = str(len(json.dumps(response_body)))
    headers = ast.literal_eval(str(headers)).items()

    return status_code, headers, json.dumps(response_body)

# Read image binary data by chunks
def readInChunks(fileObj, chunkSize = 4096):
    while True:
        data = fileObj.read(chunkSize)
        if not data:
            break
        yield data

def delete_temp_image_file(temp_file_path):
    # Delete temporary image file
    try:
        os.remove(temp_file_path)
    except:
        pass

# Generate urls of service endpoints based on neighbor list
def generate_urls_neighbor_list(url_suffix):

    # Read from cache memory
    neighbors = mc.get('neighbors')
    urls = []
    for neighbor in neighbors:
        split = neighbor.ip_address.split(':')
        url = split[0]+':'+split[1]+':'+url_suffix
        urls.append(url)

    return urls




