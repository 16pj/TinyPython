CREATE DATABASE openstack_agent;
