

class hypervisorStatistics(object):
    
    def __init__(self, cloud_ip, count, current_workload, disk_available_least, free_disk_gb, free_ram_mb, local_gb, local_gb_used, memory_mb, memory_mb_used, running_vms, vcpus, vcpus_used):
	self.cloud_ip = cloud_ip
	self.count = count
	self.current_workload = current_workload
	self.disk_available_least = disk_available_least
	self.free_disk_gb = free_disk_gb
	self.free_ram_mb = free_ram_mb
	self.local_gb = local_gb
	self.local_gb_used = local_gb_used
	self.memory_mb = memory_mb
	self.memory_mb_used = memory_mb_used
	self.running_vms = running_vms
	self.vcpus = vcpus
	self.vcpus_used = vcpus_used



